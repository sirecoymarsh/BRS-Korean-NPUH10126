# BRS 한국어 HD UI 팩

PPSSPP 전용 선택 설치 팩입니다. 총 27개 UI 텍스처를 8배 해상도로 제공합니다.
`PSP` 폴더를 PPSSPP 메모리 스틱 루트에 합친 뒤
**Replace Textures(텍스처 교체)** 를 켜십시오. ISO 파일은 변경하지 않습니다.

대상 게임 ID: `NPUH10126`

스테이지 선택 화면의 외계인명은 원작 표기
`XNFE / SAHA / MEFE / MZMA / SZZU / LLWO`를 유지합니다.
모든 이름은 `LLWO` 기준으로 중앙 정렬했으며, `SAHA` 뒤에서 `I`처럼
보이던 잔여 픽셀을 제거했습니다.
