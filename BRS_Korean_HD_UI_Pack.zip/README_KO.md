# BRS 한국어 HD UI 팩

PPSSPP 전용 선택 설치 팩입니다. `PSP` 폴더를 PPSSPP 메모리 스틱 루트에 합친 뒤 **Replace Textures(텍스처 교체)** 를 켜십시오.
ISO 파일은 변경하지 않습니다.
